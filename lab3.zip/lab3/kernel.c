#define MAX_PROC 4

typedef struct
{
    int id;
    uint8_t ACC;        // Accumulator
    uint8_t PC;       // Program Counter
    bool flagN;
    bool flagZ;
} PCB;

PCB ProcTable[MAX_PROC] = {
    {.id=0, .ACC=0, .PC=0, .flagN=false, .flagZ=false},
    {.id=1, .ACC=0, .PC=64, .flagN=false, .flagZ=false},
    {.id=2, .ACC=0, .PC=128, .flagN=false, .flagZ=false},
    {.id=3, .ACC=0, .PC=192, .flagN=false, .flagZ=false},
};

int currentProc = 0;

void kernel(int intreq)
{
    fprintf(stderr,"Kernel called for INT %d...\n",intreq);

    //SALVA
    ProcTable[currentProc].ACC = ACC;
    ProcTable[currentProc].PC = PC;
    ProcTable[currentProc].flagN = flagN;
    ProcTable[currentProc].flagZ = flagZ;

    //ATENDE
    switch (intreq)
    {
        case INT_TIMER:
        currentProc = (currentProc++)%MAX_PROC;
        break;
        case INT_DISK_OPERATION_COMPLETED:
        //libera
        
    }
    //ESCALONA

    //RESTAURA
    ACC = ProcTable[currentProc].ACC;
    PC = ProcTable[currentProc].PC;
    flagN = ProcTable[currentProc].flagN;
    flagZ = ProcTable[currentProc].flagZ;
};