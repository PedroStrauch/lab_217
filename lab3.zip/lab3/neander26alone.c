// INF - UFRGS - Sistemas Operacionais 1 N - Marcelo Johann 2026
//
// NEANDER extended simulator
//
// Added the following instructions:
// INT - Software Interruption or System Call
// IN - read from an input terminal and store in memory
// OUT - output a value from memory to a terminal display
//
// PS: Neander is too small to do actual multiprogramming, so
// this simulation is just representative, yet another toy program.

#include <stdio.h>
#include <unistd.h>

// GENERAL DEFINITIONS

#define true 1
#define false 0
#define bool char
#define uint8_t unsigned char

// TIMING

#define DELAY_PROC 200000

// NEANDER INSTRUCTIONS

enum Opcode {
        NOP=0, STA=0x10, LDA=0x20, ADD=0x30,
        OR=0x40, AND=0x50, NOT=0x60, INT=0x70,
        JMP=0x80, JN=0x90, JZ=0xA0, IN=0xB0,
        OUT=0xC0, HLT=0xF0 };

const char * const OpcodeName[16] = {
        "NOP","STA","LDA","ADD","OR ","AND","NOT","INT",
        "JMP","JN ","JZ ","IN","OUT","","","HLT"};
        
#define OPCODE(i) (i & 0xF0)

// NEANDER REGISTERS

uint8_t ACC;        // Accumulator
uint8_t PC=0;       // Program Counter
uint8_t RI=0;       // Instruction Register
bool flagN=false;
bool flagZ=true;

// RAM MEMORY

uint8_t Memory[256] = {
#include "memory.c"
};

// INTERFACES

void kernel(int number) {};
void IOput(uint8_t data) { fprintf(stderr,"PRINT(%d)\n",data); };
uint8_t IOget() { int n; scanf("%d",&n); return n; };

// UTILITIES

void printStat(void)
  {
  fprintf(stderr,"PC: %x Opcode: %s ",PC,OpcodeName[Memory[PC] >> 4]);
  fprintf(stderr,"OpAddr: %x ",Memory[PC+1]);
  fprintf(stderr,"ACC: %x \n",ACC);
  }

void UpdateNZ(void)
  {
  if ( ACC&0x80 ) flagN=true; else flagN=false;
  if ( ACC==0 ) flagZ=true; else flagZ=false;
  }

// Processor Step

void NeanderStep(bool *running)
  {
  printStat();
  // fetch
  RI = Memory[PC++];
  // execute
  switch(OPCODE(RI))
    {
    uint8_t target;
  case NOP: break;
  case STA: Memory[Memory[PC++]] = ACC; break;
  case LDA: ACC = Memory[Memory[PC++]]; UpdateNZ(); break;
  case ADD: ACC =  ACC + Memory[Memory[PC++]]; UpdateNZ(); break;
  case OR : ACC = ACC | Memory[Memory[PC++]]; UpdateNZ(); break;
  case AND: ACC = ACC & Memory[Memory[PC++]]; UpdateNZ(); break;
  case NOT: ACC = 0xFF ^ ACC; UpdateNZ(); break;
  case INT: kernel(Memory[Memory[PC++]]); break;
  case JMP: target = Memory[PC++]; PC = target; break;
  case JN : target = Memory[PC++]; if (flagN) PC = target; break;
  case JZ : target = Memory[PC++]; if (flagZ) PC = target; break;
  case IN : Memory[Memory[PC++]] = IOget(); break;
  case OUT: IOput( Memory[Memory[PC++]] ); break;
  case HLT: *running = false; break;
    }
  }

// Processor Loop

void * NeanderLoop(void *p)
  {
  bool running = true;
  
  while(running)
    {
    NeanderStep(&running);
    //getchar();
    usleep(DELAY_PROC);
    }
  return 0;
  }
  
// App main

int main()
  {
  NeanderLoop(0);
  }

// END OF FILE
