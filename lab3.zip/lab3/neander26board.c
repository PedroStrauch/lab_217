// INF - UFRGS - Sistemas Operacionais 1 N - Marcelo Johann 2026
//
// NEANDER extended simulator with "Mother Board"
//
// Alem da CPU, temos tambem:
// MMU - Memory Management Unit - empty
// INTCTRL - Controlador de Interrupções - just a number
// TTY - Terminal com streams de entrada e saida - sem INT
// TIMER - controlador de alarme - ok

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <fcntl.h>
#include <unistd.h>

// GENERAL DEFINITIONS

#define true 1
#define false 0
#define bool char
#define uint8_t unsigned char

// TIMING

#define DELAY_PROC 1000000
#define DELAY_TIMER 300000

// NEANDER INSTRUCTIONS

enum Opcode {
        NOP=0, STA=0x10, LDA=0x20, ADD=0x30,
        OR=0x40, AND=0x50, NOT=0x60, INT=0x70,
        JMP=0x80, JN=0x90, JZ=0xA0, IN=0xB0,
        OUT=0xC0, HLT=0xF0 };

const char * const OpcodeName[16] = {
        "NOP","STA","LDA","ADD","OR ","AND","NOT","INT",
        "JMP","JN ","JZ ","IN","OUT","","","HLT"};
        
#define OPCODE(i) (i & 0xF0)

// NEANDER REGISTERS

uint8_t ACC;        // Accumulator
uint8_t PC=0;       // Program Counter
uint8_t RI=0;       // Instruction Register
bool flagN=false;
bool flagZ=true;

// RAM MEMORY

#define MEM_SIZE 256
uint8_t Memory[MEM_SIZE] = {
#include "memory.c"
};

// GLOBAL CONTROL

bool running = true;

// MMU

int memRead(int add)
  {
  if (add<0 || add> MEM_SIZE)
    return 0;
  return Memory[add];
  }
  
void memWrite(int add, int val)
  {
  if (add<0 || add> MEM_SIZE)
    return;
  Memory[add]=val;
  }
  
// INT CONTROLLER

#define INT_TIMER 2
#define INT_INPUT 3

typedef struct
  {
  int number;
  } INT_CTRL;
  
INT_CTRL IntController = {0};

void setInterrupt(int num)  { IntController.number = num; }
int getInterrupt(void)      { return IntController.number;}
void resetInterrupt(void)   { IntController.number = 0; }

// KERNEL PLACEHOLDER

void kernel(int intreq);

// IO SYSTEM - TTY

uint8_t inputBuffer = -1;
void IOput(uint8_t data) { fprintf(stderr,"PRINT(%d)\n",data); };
uint8_t IOget() { uint8_t data = inputBuffer; inputBuffer = -1; return data; };

// UTILITIES

void printStat(void)
  {
  fprintf(stderr,"PC: %x Opcode: %s OpAddr: %x ACC: %x \n",
    PC, OpcodeName[memRead(PC) >> 4], memRead(PC+1), ACC );
  }

void UpdateNZ(void)
  {
  if ( ACC&0x80 ) flagN=true; else flagN=false;
  if ( ACC==0 ) flagZ=true; else flagZ=false;
  }

// Processor Step

void NeanderStep(bool *running)
  {
  int intreq = 0; // interrupt request
  // fetch
  printStat();
  RI = memRead(PC++);
  // execute
  switch(OPCODE(RI))
    {
    uint8_t target;
  case NOP: break;
  case STA: memWrite(memRead(PC++),ACC); break;
  case LDA: ACC = memRead(memRead(PC++)); UpdateNZ(); break;
  case ADD: ACC =  ACC + memRead(memRead(PC++)); UpdateNZ(); break;
  case OR : ACC = ACC | memRead(memRead(PC++)); UpdateNZ(); break;
  case AND: ACC = ACC & memRead(memRead(PC++)); UpdateNZ(); break;
  case NOT: ACC = 0xFF ^ ACC; UpdateNZ(); break;
  case INT: kernel(memRead(memRead(PC++))); break;
  case JMP: target = memRead(PC++); PC = target; break;
  case JN : target = memRead(PC++); if (flagN) PC = target; break;
  case JZ : target = memRead(PC++); if (flagZ) PC = target; break;
  case IN : memWrite(memRead(PC++), IOget()); break;
  case OUT: IOput( memRead(memRead(PC++)) ); break;
  case HLT: *running = false; break;
    }
  // CHECK HW Interrupts
  if ((intreq = getInterrupt()) != 0)
    {
    kernel(intreq);
    resetInterrupt();
    }
  }

// Processor Loop

void * functionNeanderLoop(void *p)
  {
  while(running)
    {
    NeanderStep(&running);
    usleep(DELAY_PROC);
    }
  return 0;
  }
  
void *functionTimer( void * s)
  {
  while (running)
    {
    fprintf(stderr,"\ttick\n");
    setInterrupt(INT_TIMER);
    usleep(DELAY_TIMER);
    }
  return 0;
  }

void *functionKeyboard( void * s)
  {
  int data;
  while (running)
    {
    if ( 0 == scanf("%d",&data) )
      {
      fprintf(stderr,"Simulation ended by reading non-numeric key.\n");
      running = false;
      }
    inputBuffer = (uint8_t) data;
    fprintf(stderr,"\t\t\tKEYBOARD(%d)\n",data);
    // MUST SET INT FOR BLOCKING KEYBOARD INPUT
    }
  return 0;
  }
  
// App main

int main()
  {
  char command = ' ';
  pthread_t tproc;
  pthread_t ttimer;
  pthread_t tkeyboard;
  
  printf("NEANDER BOARD V0\n");
  
  pthread_create(&tproc, 0 ,functionNeanderLoop,  0);
  pthread_create(&ttimer, 0 ,functionTimer,  0);
  pthread_create(&tkeyboard, 0 ,functionKeyboard,  0);
  
  // wait for the user to command EXIT: all threads will stop after a while
  
  fprintf(stderr,"All threads created...\n");
  while (running)
    ;
  
  pthread_join(tproc, NULL);
  pthread_join(ttimer, NULL);
  pthread_join(tkeyboard, NULL);
  return 0;
  }

#include "kernel.c"
// END OF FILE
